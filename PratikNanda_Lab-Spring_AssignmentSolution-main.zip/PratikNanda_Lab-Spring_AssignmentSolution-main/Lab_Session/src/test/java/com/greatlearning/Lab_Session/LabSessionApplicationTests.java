package com.greatlearning.Lab_Session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
